package com.udacity.pricing.service;

public class PriceException extends Exception {

    public PriceException(String message) {
        super(message);
    }
}
